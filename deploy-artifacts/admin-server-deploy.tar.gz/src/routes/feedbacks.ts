import { Router, Request, Response } from 'express';
import { ObjectId } from 'mongodb';
import { Parser } from 'json2csv';
import { adminDB } from '../config/database';
import { FeedbackListItem, FeedbackStatus, FeedbackType, InternalNote } from '../types';
import { requireAuth } from '../middleware/auth';
import { auditLog } from '../middleware/auditLog';
import { feedbackService } from '../services/feedbackService';
import { escapeRegex } from '../utils/validators';
import { notifyFeedbackPush } from '../services/cacheNotify';

const router = Router();

/**
 * 合法的反馈状态值
 */
const VALID_STATUS: FeedbackStatus[] = ['pending', 'processing', 'resolved', 'closed'];

/**
 * 合法的反馈类型值
 */
const VALID_TYPES: FeedbackType[] = ['功能异常', '界面问题', '建议', '其他'];

/**
 * 构建反馈查询筛选条件
 * 根据请求查询参数构建MongoDB筛选器
 * @param query - 请求查询参数对象
 * @returns MongoDB筛选条件对象
 */
function buildFilter(query: Record<string, unknown>): Record<string, unknown> {
  const filter: Record<string, unknown> = {};

  const type = query.type as string | undefined;
  if (type && VALID_TYPES.includes(type as FeedbackType)) {
    filter.type = type;
  }

  const status = query.status as string | undefined;
  if (status && VALID_STATUS.includes(status as FeedbackStatus)) {
    filter.status = status;
  }

  const startDate = query.startDate as string | undefined;
  const endDate = query.endDate as string | undefined;
  if (startDate || endDate) {
    const dateFilter: Record<string, unknown> = {};
    if (startDate) {
      dateFilter.$gte = new Date(startDate);
    }
    if (endDate) {
      dateFilter.$lte = new Date(endDate);
    }
    filter.createdAt = dateFilter;
  }

  const keyword = query.keyword as string | undefined;
  if (keyword && keyword.trim()) {
    const safeKeyword = escapeRegex(keyword.trim());
    filter.title = { $regex: safeKeyword, $options: 'i' };
  }

  const assignee = query.assignee as string | undefined;
  if (assignee && assignee.trim()) {
    filter.assignee = assignee.trim();
  }

  return filter;
}

/**
 * GET /
 * 获取反馈分页列表
 * 查询参数：page、pageSize、type、status、startDate、endDate、keyword
 */
router.get('/', requireAuth, async (req: Request, res: Response) => {
  try {
    const page = Math.max(1, Number(req.query.page) || 1);
    const pageSize = Math.max(1, Math.min(Number(req.query.pageSize) || 20, 100));
    const skip = (page - 1) * pageSize;

    const filter = buildFilter(req.query as Record<string, unknown>);

    console.log('[Admin反馈] 查询列表, isConnected:', adminDB.isConnected(), ', page:', page, ', pageSize:', pageSize, ', filterKeys:', Object.keys(filter));

    const feedbacks = await adminDB.find('feedbacks', filter as never, {
      sort: { createdAt: -1 },
      skip,
      limit: pageSize,
    });

    const total = await adminDB.countDocuments('feedbacks', filter as never);

    console.log('[Admin反馈] 查询结果:', feedbacks.length, '条, 总数:', total);

    if (feedbacks.length === 0 && total === 0) {
      console.log('[Admin反馈] 未查询到任何反馈记录，请确认主服务端反馈数据是否已写入MongoDB');
    }

    const items: FeedbackListItem[] = feedbacks.map((item: Record<string, unknown>) => ({
      _id: (item._id as { toString(): string }).toString(),
      title: item.title as string,
      description: item.description as string,
      type: item.type as FeedbackType,
      contact: item.contact as string,
      visitorIp: item.visitorIp as string,
      visitorId: (item.visitorId as string) || 'anonymous',
      status: item.status as FeedbackStatus,
      createdAt: new Date(item.createdAt as Date).toISOString(),
      assignee: (item.assignee as string) || undefined,
      assignedAt: item.assignedAt ? new Date(item.assignedAt as Date).toISOString() : undefined,
      internalNotes: (item.internalNotes as InternalNote[]) || undefined,
      slaDeadline: item.slaDeadline ? new Date(item.slaDeadline as Date).toISOString() : undefined,
      slaHours: (item.slaHours as number) || undefined,
    }));

    res.json({
      success: true,
      data: {
        items,
        total,
        page,
        pageSize,
      },
    });
  } catch (error) {
    console.error('获取反馈列表失败:', error);
    res.status(500).json({ success: false, error: '获取反馈列表失败' });
  }
});

/**
 * GET /stats
 * 获取反馈统计数据
 */
router.get('/stats', requireAuth, async (_req: Request, res: Response) => {
  try {
    const stats = await feedbackService.getStats();
    res.json({ success: true, data: stats });
  } catch (error) {
    console.error('获取反馈统计失败:', error);
    res.status(500).json({ success: false, error: '获取反馈统计失败' });
  }
});

/**
 * PATCH /:id/status
 * 更新反馈状态
 * 请求体：{ status: FeedbackStatus }
 * 需要审计日志记录
 */
router.patch(
  '/:id/status',
  requireAuth,
  auditLog('更新反馈状态', 'feedback'),
  async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const { status } = req.body;

      if (!id || !ObjectId.isValid(id)) {
        res.status(400).json({ success: false, error: '无效的反馈ID' });
        return;
      }

      if (!status || !VALID_STATUS.includes(status)) {
        res.status(400).json({
          success: false,
          error: `无效的状态值，必须为：${VALID_STATUS.join('/')}`,
        });
        return;
      }

      const feedback = await adminDB.findOne('feedbacks', { _id: new ObjectId(id) } as never);
      if (!feedback) {
        res.status(404).json({ success: false, error: '反馈不存在' });
        return;
      }

      await adminDB.updateOne(
        'feedbacks',
        { _id: new ObjectId(id) } as never,
        { $set: { status } }
      );

      res.json({
        success: true,
        message: '反馈状态已更新',
        data: {
          visitorId: (feedback as Record<string, unknown>).visitorId as string || 'anonymous',
          title: (feedback as Record<string, unknown>).title as string || '',
          status,
        },
      });

      if (status !== 'pending' && (feedback as Record<string, unknown>).visitorId && (feedback as Record<string, unknown>).visitorId !== 'anonymous') {
        notifyFeedbackPush((feedback as Record<string, unknown>).visitorId as string, ((feedback as Record<string, unknown>).title as string) || '', status).catch((err: unknown) => {
          console.error('[反馈推送] 异步推送失败:', err instanceof Error ? err.message : String(err));
        });
      }
    } catch (error) {
      console.error('更新反馈状态失败:', error);
      res.status(500).json({ success: false, error: '更新反馈状态失败' });
    }
  }
);

/**
 * POST /export
 * 导出反馈数据为CSV格式
 * 查询参数同列表筛选
 */
router.post('/export', requireAuth, async (req: Request, res: Response) => {
  try {
    const filter = buildFilter(req.query as Record<string, unknown>);

    const feedbacks = await adminDB.find('feedbacks', filter as never, {
      sort: { createdAt: -1 },
      limit: 10000,
    });

    const exportData = feedbacks.map((item: Record<string, unknown>) => ({
      ID: (item._id as { toString(): string }).toString(),
      标题: item.title as string,
      描述: item.description as string,
      类型: item.type as string,
      联系方式: item.contact as string,
      访客IP: item.visitorIp as string,
      状态: item.status as string,
      创建时间: new Date(item.createdAt as Date).toISOString(),
    }));

    const fields = ['ID', '标题', '描述', '类型', '联系方式', '访客IP', '状态', '创建时间'];
    const parser = new Parser({ fields });
    const csv = parser.parse(exportData);

    const filename = `feedbacks_${new Date().toISOString().split('T')[0]}.csv`;
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send('\uFEFF' + csv);
  } catch (error) {
    console.error('导出反馈数据失败:', error);
    res.status(500).json({ success: false, error: '导出反馈数据失败' });
  }
});

/**
 * PUT /:id/assign
 * 分配反馈工单给指定管理员
 * 请求体：{ assignee: string, slaHours?: number }
 * 设置 assignee、assignedAt、slaDeadline 字段
 * slaHours 默认 48 小时
 */
router.put(
  '/:id/assign',
  requireAuth,
  auditLog('分配反馈工单', 'feedback'),
  async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const { assignee, slaHours } = req.body as {
        assignee?: string;
        slaHours?: number;
      };

      if (!id || !ObjectId.isValid(id)) {
        res.status(400).json({ success: false, error: '无效的反馈ID' });
        return;
      }

      if (!assignee || typeof assignee !== 'string' || assignee.trim().length === 0) {
        res.status(400).json({ success: false, error: '被分配人昵称不能为空' });
        return;
      }

      const feedback = await adminDB.findOne('feedbacks', { _id: new ObjectId(id) } as never);
      if (!feedback) {
        res.status(404).json({ success: false, error: '反馈不存在' });
        return;
      }

      const hours = slaHours && slaHours > 0 ? slaHours : 48;
      const now = new Date();
      const slaDeadline = new Date(now.getTime() + hours * 60 * 60 * 1000);

      await adminDB.updateOne(
        'feedbacks',
        { _id: new ObjectId(id) } as never,
        {
          $set: {
            assignee: assignee.trim(),
            assignedAt: now,
            slaHours: hours,
            slaDeadline,
          },
        }
      );

      res.json({
        success: true,
        message: '工单已分配',
        data: {
          assignee: assignee.trim(),
          assignedAt: now.toISOString(),
          slaHours: hours,
          slaDeadline: slaDeadline.toISOString(),
        },
      });
    } catch (error) {
      console.error('分配工单失败:', error);
      res.status(500).json({ success: false, error: '分配工单失败' });
    }
  }
);

/**
 * POST /:id/notes
 * 添加内部备注
 * 请求体：{ content: string }
 * 从 session 读取 author（管理员昵称）
 */
router.post(
  '/:id/notes',
  requireAuth,
  auditLog('添加反馈内部备注', 'feedback'),
  async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const { content } = req.body as { content?: string };

      if (!id || !ObjectId.isValid(id)) {
        res.status(400).json({ success: false, error: '无效的反馈ID' });
        return;
      }

      if (!content || typeof content !== 'string' || content.trim().length === 0) {
        res.status(400).json({ success: false, error: '备注内容不能为空' });
        return;
      }

      const feedback = await adminDB.findOne('feedbacks', { _id: new ObjectId(id) } as never);
      if (!feedback) {
        res.status(404).json({ success: false, error: '反馈不存在' });
        return;
      }

      const author = ((req as unknown as Record<string, unknown>).adminNickname as string) || '未知管理员';
      const now = new Date();
      const note: InternalNote = {
        content: content.trim(),
        author,
        createdAt: now,
      };

      await adminDB.updateOne(
        'feedbacks',
        { _id: new ObjectId(id) } as never,
        { $push: { internalNotes: note } } as never
      );

      res.json({
        success: true,
        message: '备注已添加',
        data: {
          content: note.content,
          author: note.author,
          createdAt: now.toISOString(),
        },
      });
    } catch (error) {
      console.error('添加备注失败:', error);
      res.status(500).json({ success: false, error: '添加备注失败' });
    }
  }
);

/**
 * GET /:id/notes
 * 获取内部备注列表
 * 返回指定反馈工单的所有内部备注
 */
router.get('/:id/notes', requireAuth, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    if (!id || !ObjectId.isValid(id)) {
      res.status(400).json({ success: false, error: '无效的反馈ID' });
      return;
    }

    const feedback = await adminDB.findOne('feedbacks', { _id: new ObjectId(id) } as never);
    if (!feedback) {
      res.status(404).json({ success: false, error: '反馈不存在' });
      return;
    }

    const notes = ((feedback as Record<string, unknown>).internalNotes as InternalNote[]) || [];

    const formattedNotes = notes.map((note) => ({
      content: note.content,
      author: note.author,
      createdAt: new Date(note.createdAt).toISOString(),
    }));

    res.json({
      success: true,
      data: formattedNotes,
    });
  } catch (error) {
    console.error('获取备注列表失败:', error);
    res.status(500).json({ success: false, error: '获取备注列表失败' });
  }
});

export default router;
